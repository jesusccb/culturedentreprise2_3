package persistence;

@javax.persistence.Entity
@javax.persistence.Table(name = "CONVICTION")
@javax.persistence.DiscriminatorValue("1")
public class Conviction extends Judicial_decision {

    @Override
    public String get_decision_type_number() {
        return "1";
    }

    @javax.persistence.Column(name = "DURATION")
    private Integer _duration;

    public Integer get_duration() {
        return _duration;
    }

    public void set_duration(Integer duration) {
        _duration = duration;
    }

    public Conviction() {
        this(null, null);
    }

    public Conviction(Judicial_decisionPK pk) {
        this(pk.get_prison_file_number(), pk.get_date_of_decision());
    }

    public Conviction(String prison_file_number, java.util.Date date_of_decision) {
        super("1", prison_file_number, date_of_decision);
    }

    @Override
    public String toString() {
        return "Conviction";
    }
}
