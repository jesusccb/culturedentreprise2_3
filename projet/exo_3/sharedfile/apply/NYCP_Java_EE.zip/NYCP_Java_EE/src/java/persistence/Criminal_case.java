package persistence;

@javax.persistence.Entity
@javax.persistence.Table(name = "CRIMINAL_CASE")
@javax.persistence.NamedQueries({
    @javax.persistence.NamedQuery(name = "Criminal_case.All", query = "SELECT c FROM Criminal_case c"),
    @javax.persistence.NamedQuery(name = "Criminal_case.Deletable", query = "SELECT c FROM Criminal_case c WHERE NOT EXISTS (SELECT p FROM Prisoner p WHERE p._incarceration_main._criminal_casePK = c._criminal_casePK)")})
public class Criminal_case implements java.io.Serializable {

    private static final long serialVersionUID = 1L;

    @javax.persistence.EmbeddedId
    protected Criminal_casePK _criminal_casePK;

    public Criminal_casePK get_criminal_casePK() {
        return _criminal_casePK;
    }

    public void set_criminal_casePK(Criminal_casePK criminal_casePK) {
        _criminal_casePK = criminal_casePK;
    }

    public String get_criminal_case_number() {
        return _criminal_casePK.get_criminal_case_number();
    }

    public void set_criminal_case_number(String criminal_case_number) {
        _criminal_casePK.set_criminal_case_number(criminal_case_number);
    }

    public String get_jurisdiction_name() {
        return _criminal_casePK.get_jurisdiction_name();
    }

    public void set_jurisdiction_name(String jurisdiction_name) {
        _criminal_casePK.set_jurisdiction_name(jurisdiction_name);
    }
    @javax.persistence.Column(name = "DATE_OF_CRIMINAL_CASE")
    @javax.persistence.Temporal(javax.persistence.TemporalType.DATE)
    private java.util.Date _date_of_criminal_case = new java.util.Date();

    public java.util.Date get_date_of_criminal_case() {
        return _date_of_criminal_case;
    }

    public void set_date_of_criminal_case(java.util.Date date_of_criminal_case) {
        _date_of_criminal_case = date_of_criminal_case;
    }

    @javax.persistence.ManyToMany(mappedBy = "_offense") // 'Criminal_case' does not own the relationship. So, 'cascade' attribute setup is a priori useless? 
    private java.util.Set<Prisoner> _participant = new java.util.LinkedHashSet();

    public java.util.Set<Prisoner> get_participant() {
        return _participant;
    }

    public void set_participant(java.util.Set<Prisoner> participant) {
        _participant = participant;
    }

    public Criminal_case() {
        _criminal_casePK = new Criminal_casePK();
    }

    public Criminal_case(Criminal_casePK criminal_casePK) {
        _criminal_casePK = criminal_casePK;
    }

    public Criminal_case(String criminal_case_number, String jurisdiction_name) {
        _criminal_casePK = new Criminal_casePK(criminal_case_number, jurisdiction_name);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (_criminal_casePK != null ? _criminal_casePK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof Criminal_case)) {
            return false;
        } else {
            Criminal_case other = (Criminal_case) object;
            if ((_criminal_casePK == null && other._criminal_casePK != null) || (_criminal_casePK != null && !_criminal_casePK.equals(other._criminal_casePK))) {
                return false;
            }
        }
        return true;
    }

    @Override
    public String toString() {
        return _criminal_casePK.toString();
    }

}
