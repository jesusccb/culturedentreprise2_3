package persistence;

@javax.persistence.Embeddable
public class Criminal_casePK implements java.io.Serializable {

    @javax.persistence.Basic(optional = false)
    @javax.validation.constraints.NotNull
    @javax.validation.constraints.Size(min = 1, max = 10)
    @javax.persistence.Column(name = "CRIMINAL_CASE_NUMBER")
    private String _criminal_case_number;

    public String get_criminal_case_number() {
        return _criminal_case_number;
    }

    public void set_criminal_case_number(String criminal_case_number) {
        _criminal_case_number = criminal_case_number;
    }

    @javax.persistence.Basic(optional = false)
    @javax.validation.constraints.NotNull
    @javax.validation.constraints.Size(min = 1, max = 30)
    @javax.persistence.Column(name = "JURISDICTION_NAME")
    private String _jurisdiction_name;

    public String get_jurisdiction_name() {
        return _jurisdiction_name;
    }

    public void set_jurisdiction_name(String jurisdiction_name) {
        _jurisdiction_name = jurisdiction_name;
    }

    public Criminal_casePK() {
        _criminal_case_number = "";
        _jurisdiction_name = "";
    }

    public Criminal_casePK(String criminal_case_number, String jurisdiction_name) {
        _criminal_case_number = criminal_case_number;
        _jurisdiction_name = jurisdiction_name;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (_criminal_case_number != null ? _criminal_case_number.hashCode() : 0);
        hash += (_jurisdiction_name != null ? _jurisdiction_name.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof Criminal_casePK)) {
            return false;
        } else {
            Criminal_casePK other = (Criminal_casePK) object;
            if (!_criminal_case_number.equals(other._criminal_case_number) || !_jurisdiction_name.equals(other._jurisdiction_name)) {
                return false;
            }
        }
        return true;
    }

    @Override
    public String toString() {
        return _criminal_case_number + '-' + _jurisdiction_name;
    }

    /**
     * Utility for JSF converter:
     */
    public static Criminal_casePK To_criminal_casePK(String criminal_casePK) {
        String pk[] = criminal_casePK.split("-");
        return new Criminal_casePK(pk[0], pk[1]);
    }
}
