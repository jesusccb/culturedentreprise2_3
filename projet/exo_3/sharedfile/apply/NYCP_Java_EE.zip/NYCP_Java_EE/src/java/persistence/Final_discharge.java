package persistence;

@javax.persistence.Entity
@javax.persistence.Table(name = "FINAL_DISCHARGE")
@javax.persistence.DiscriminatorValue("2")
public class Final_discharge extends Judicial_decision {

    @Override
    public String get_decision_type_number() {
        return "2";
    }

    @javax.persistence.Column(name = "DATE_OF_FINAL_DISCHARGE")
    @javax.persistence.Temporal(javax.persistence.TemporalType.DATE)
    private java.util.Date _date_of_final_discharge;

    public java.util.Date get_date_of_final_discharge() {
        return _date_of_final_discharge;
    }

    public void set_date_of_final_discharge(java.util.Date date_of_final_discharge) {
        _date_of_final_discharge = date_of_final_discharge;
    }

    public Final_discharge() {
        this(null, null);
    }

    public Final_discharge(Judicial_decisionPK pk) {
        this(pk.get_prison_file_number(), pk.get_date_of_decision());
    }

    public Final_discharge(String prison_file_number, java.util.Date date_of_decision) {
        super("2", prison_file_number, date_of_decision);
    }

    @Override
    public String toString() {
        return "Final discharge";
    }
}
