package persistence;

@javax.persistence.Entity
@javax.persistence.Table(name = "JUDICIAL_DECISION")
@javax.persistence.NamedQueries({
    @javax.persistence.NamedQuery(name = "Judicial_decision.All", query = "SELECT j FROM Judicial_decision j")})
@javax.persistence.Inheritance(strategy = javax.persistence.InheritanceType.JOINED)
@javax.persistence.DiscriminatorColumn(name = "DECISION_TYPE_NUMBER", discriminatorType = javax.persistence.DiscriminatorType.STRING)
public abstract class Judicial_decision implements java.io.Serializable {

    private static final long serialVersionUID = 1L;

    @javax.persistence.EmbeddedId
    protected Judicial_decisionPK _judicial_decisionPK;

    public Judicial_decisionPK get_judicial_decisionPK() {
        return _judicial_decisionPK;
    }

    public void set_judicial_decisionPK(Judicial_decisionPK judicial_decisionPK) {
        _judicial_decisionPK = new Judicial_decisionPK(judicial_decisionPK.get_decision_type_number(), judicial_decisionPK.get_prison_file_number(), judicial_decisionPK.get_date_of_decision());
    }

    abstract public String get_decision_type_number();

    public String get_prison_file_number() {
        return _judicial_decisionPK.get_prison_file_number();
    }

    public java.util.Date get_date_of_decision() {
        return _judicial_decisionPK.get_date_of_decision();
    }

    public Judicial_decision() {
        _judicial_decisionPK = new Judicial_decisionPK();
    }

    public Judicial_decision(Judicial_decisionPK judicial_decisionPK) {
        _judicial_decisionPK = judicial_decisionPK;
    }

    public Judicial_decision(String decision_type_number, String prison_file_number, java.util.Date date_of_decision) {
        _judicial_decisionPK = new Judicial_decisionPK(decision_type_number, prison_file_number, date_of_decision);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (_judicial_decisionPK != null ? _judicial_decisionPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof Judicial_decision)) {
            return false;
        } else {
            Judicial_decision other = (Judicial_decision) object;
            if ((_judicial_decisionPK == null && other._judicial_decisionPK != null) || (_judicial_decisionPK != null && !_judicial_decisionPK.equals(other._judicial_decisionPK))) {
                return false;
            }
        }
        return true;
    }

    @Override
    public String toString() {
        return get_decision_type_number() + _judicial_decisionPK.toString();
    }
}
