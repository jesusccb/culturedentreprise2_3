package persistence;

@javax.persistence.Embeddable
public class Judicial_decisionPK implements java.io.Serializable {

    @javax.persistence.Basic(optional = false)
    @javax.validation.constraints.NotNull
    @javax.validation.constraints.Size(min = 1, max = 1)
    @javax.persistence.Column(name = "DECISION_TYPE_NUMBER")
    private String _decision_type_number;

    public String get_decision_type_number() {
        return _decision_type_number;
    }

    public void set_decision_type_number(String decision_type_number) {
        _decision_type_number = decision_type_number;
    }

    @javax.persistence.Basic(optional = false)
    @javax.validation.constraints.NotNull
    @javax.validation.constraints.Size(min = 1, max = 10)
    @javax.persistence.Column(name = "PRISON_FILE_NUMBER")
    private String _prison_file_number;

    public String get_prison_file_number() {
        return _prison_file_number;
    }

    public void set_prison_file_number(String prison_file_number) {
        _prison_file_number = prison_file_number;
    }

    @javax.persistence.Basic(optional = false)
    @javax.validation.constraints.NotNull
    @javax.persistence.Column(name = "DATE_OF_DECISION")
    @javax.persistence.Temporal(javax.persistence.TemporalType.DATE)
    private java.util.Date _date_of_decision;

    public java.util.Date get_date_of_decision() {
        return _date_of_decision;
    }

    public void set_date_of_decision(java.util.Date date_of_decision) {
        _date_of_decision = date_of_decision;
    }

    public Judicial_decisionPK() {
        _decision_type_number = "";
        _prison_file_number = "";
        _date_of_decision = new java.util.Date();
    }

    public Judicial_decisionPK(String decision_type_number, String prison_file_number, java.util.Date date_of_decision) {
        _decision_type_number = decision_type_number;
        _prison_file_number = prison_file_number;
        _date_of_decision = date_of_decision;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (_decision_type_number != null ? _decision_type_number.hashCode() : 0);
        hash += (_prison_file_number != null ? _prison_file_number.hashCode() : 0);
        hash += (_date_of_decision != null ? _date_of_decision.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof Judicial_decisionPK)) {
            return false;
        } else {
            Judicial_decisionPK other = (Judicial_decisionPK) object;
            if (!_decision_type_number.equals(other._decision_type_number) || !_prison_file_number.equals(other._prison_file_number) || !_date_of_decision.equals(other._date_of_decision)) {
                return false;
            }
        }
        return true;
    }

    @Override
    public String toString() {
        return _decision_type_number + '-' + _prison_file_number + '-' + _date_of_decision;
    }
}
