package persistence;

@javax.persistence.Entity
@javax.persistence.Table(name = "MOTIVE")
@javax.persistence.NamedQueries({
    @javax.persistence.NamedQuery(name = "Motive.All", query = "SELECT m FROM Motive m"),
    @javax.persistence.NamedQuery(name = "Motive.Deletable", query = "SELECT m FROM Motive m WHERE NOT EXISTS (SELECT p FROM Prisoner p WHERE p._incarceration_motive._motive_number = m._motive_number)")})
public class Motive implements java.io.Serializable {

    private static final long serialVersionUID = 1L;

    @javax.persistence.Id
    @javax.persistence.Column(name = "MOTIVE_NUMBER")
    private String _motive_number;

    public String get_motive_number() {
        return _motive_number;
    }

    public void set_motive_number(String motive_number) {
        _motive_number = motive_number;
    }

    public String get_motive_label() {
        return _motive_label;
    }

    public void set_motive_label(String motive_label) {
        _motive_label = motive_label;
    }

    @javax.persistence.Column(name = "MOTIVE_LABEL")
    private String _motive_label;

    public Motive() {
    }

    public Motive(String motive_number, String motive_label) {
        _motive_number = motive_number;
        _motive_label = motive_label;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 71 * hash + java.util.Objects.hashCode(_motive_number);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (object == null) {
            return false;
        } else if (getClass() != object.getClass()) {
            return false;
        } else {
            final Motive other = (Motive) object;
            if (!java.util.Objects.equals(_motive_number, other._motive_number)) {
                return false;
            }
        }
        return true;
    }

    @Override
    public String toString() {
        return _motive_number + '-' + _motive_label;
    }
}
