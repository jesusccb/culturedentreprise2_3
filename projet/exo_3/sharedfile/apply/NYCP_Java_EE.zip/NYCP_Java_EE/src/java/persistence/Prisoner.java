package persistence;

@javax.persistence.Entity
@javax.persistence.Table(name = "PRISONER")
@javax.persistence.NamedNativeQuery(name = "Prisoner.Under_remand_SQL", query = "SELECT * FROM Prisoner WHERE prison_file_number NOT IN (SELECT prison_file_number FROM Conviction)")
@javax.persistence.NamedQueries({
    @javax.persistence.NamedQuery(name = "Prisoner.All_JPQL", query = "SELECT p FROM Prisoner p"),
    @javax.persistence.NamedQuery(name = "Prisoner.Under_remand_JPQL", query = "SELECT p FROM Prisoner p WHERE p._conviction IS EMPTY"),
    @javax.persistence.NamedQuery(name = "Prisoner.Not_involved_in_criminal_case_V1", query = "SELECT p FROM Prisoner p WHERE :criminal_case NOT MEMBER OF p._offense"),
    @javax.persistence.NamedQuery(name = "Prisoner.Not_involved_in_criminal_case_V2", query = "SELECT p1 FROM Prisoner p1 WHERE p1 NOT IN (SELECT p2 FROM Criminal_case c INNER JOIN c._participant p2 WHERE c = :criminal_case)")
})
public class Prisoner implements java.io.Serializable {

    private static final long serialVersionUID = 1L;

    @javax.persistence.Id
    @javax.persistence.Basic(optional = false)
    @javax.validation.constraints.NotNull
    @javax.validation.constraints.Size(min = 1, max = 10)
    @javax.persistence.Column(name = "PRISON_FILE_NUMBER")
    private String _prison_file_number;

    public String get_prison_file_number() {
        return _prison_file_number;
    }

    public void set_prison_file_number(String prison_file_number) {
        _prison_file_number = prison_file_number;
    }

    @javax.validation.constraints.Size(max = 30)
    @javax.persistence.Column(name = "GIVEN_NAME")
    private String _given_name;

    public String get_given_name() {
        return _given_name;
    }

    public void set_given_name(String given_name) {
        _given_name = given_name;
    }

    @javax.validation.constraints.Size(max = 30)
    @javax.persistence.Column(name = "SURNAME")
    private String _surname;

    public String get_surname() {
        return _surname;
    }

    public void set_surname(String surname) {
        _surname = surname;
    }

    @javax.persistence.Column(name = "DATE_OF_BIRTH")
    @javax.persistence.Temporal(javax.persistence.TemporalType.DATE)
    private java.util.Date _date_of_birth;

    public java.util.Date get_date_of_birth() {
        return _date_of_birth;
    }

    public void set_date_of_birth(java.util.Date date_of_birth) {
        _date_of_birth = date_of_birth;
    }

    @javax.validation.constraints.Size(max = 30)
    @javax.persistence.Column(name = "PLACE_OF_BIRTH")
    private String _place_of_birth;

    public String get_place_of_birth() {
        return _place_of_birth;
    }

    public void set_place_of_birth(String place_of_birth) {
        _place_of_birth = place_of_birth;
    }

    @javax.persistence.Column(name = "DATE_OF_INCARCERATION")
    @javax.persistence.Temporal(javax.persistence.TemporalType.DATE)
    private java.util.Date _date_of_incarceration;

    public java.util.Date get_date_of_incarceration() {
        return _date_of_incarceration;
    }

    public void set_date_of_incarceration(java.util.Date date_of_incarceration) {
        _date_of_incarceration = date_of_incarceration;
    }

    @javax.persistence.ManyToOne(optional = false)
    @javax.persistence.JoinColumns({
        @javax.persistence.JoinColumn(name = "CRIMINAL_CASE_NUMBER", referencedColumnName = "CRIMINAL_CASE_NUMBER"),
        @javax.persistence.JoinColumn(name = "JURISDICTION_NAME", referencedColumnName = "JURISDICTION_NAME")
    })
    private Criminal_case _incarceration_main;

    public Criminal_case get_incarceration_main() {
        return _incarceration_main;
    }

    public void set_incarceration_main(Criminal_case incarceration_main) {
        _offense.add(incarceration_main);
        _incarceration_main = incarceration_main;
    }

    @javax.persistence.ManyToOne(optional = false)
    @javax.persistence.JoinColumn(name = "MOTIVE_NUMBER", referencedColumnName = "MOTIVE_NUMBER")
    private Motive _incarceration_motive;

    public Motive get_incarceration_motive() {
        return _incarceration_motive;
    }

    public void set_incarceration_motive(Motive incarceration_motive) {
        _incarceration_motive = incarceration_motive;
    }

    // "Prisoner.Not_involved_in_criminal_case_V2" query requires 'cascade = javax.persistence.CascadeType.MERGE':
    @javax.persistence.ManyToMany(/* cascade = javax.persistence.CascadeType.MERGE */) // 'Prisoner' owns the relationship
    @javax.persistence.JoinTable(name = "PRISONER_CRIMINAL_CASE", joinColumns = {
        @javax.persistence.JoinColumn(name = "PRISON_FILE_NUMBER", referencedColumnName = "PRISON_FILE_NUMBER")},
            // 'CRIMINAL_CASE_NUMBER'-'JURISDICTION_NAME' is a foreign key in 'PRISONER_CRIMINAL_CASE' to 'Criminal_case':
            inverseJoinColumns = {
                @javax.persistence.JoinColumn(name = "CRIMINAL_CASE_NUMBER", referencedColumnName = "CRIMINAL_CASE_NUMBER"),
                @javax.persistence.JoinColumn(name = "JURISDICTION_NAME", referencedColumnName = "JURISDICTION_NAME")
            })
    private java.util.Set<Criminal_case> _offense = new java.util.LinkedHashSet();

    public java.util.Set<Criminal_case> get_offense() {
        return _offense;
    }

    public void set_offense(java.util.Set<Criminal_case> offense) {
        _offense = offense;
    }

    @javax.persistence.OneToMany(cascade = javax.persistence.CascadeType.REMOVE)
    @javax.persistence.JoinColumn(name = "PRISON_FILE_NUMBER")
    private java.util.Set<Judicial_decision> _judicial_decision;

    public java.util.Set<Judicial_decision> get_judicial_decision() {
        return _judicial_decision;
    }

    public void set_judicial_decision(java.util.Set<Judicial_decision> judicial_decision) {
        _judicial_decision = judicial_decision;
    }

    @javax.persistence.OneToMany
    @javax.persistence.JoinColumn(name = "PRISON_FILE_NUMBER")
    private java.util.Set<Conviction> _conviction;

    public java.util.Set<Conviction> get_conviction() {
        return _conviction != null ? _conviction : new java.util.HashSet();
    }

    public void set_conviction(java.util.Set<Conviction> conviction) {
        _conviction = conviction;
    }

    @javax.persistence.OneToMany
    @javax.persistence.JoinColumn(name = "PRISON_FILE_NUMBER")
    private java.util.Set<Final_discharge> _final_discharge;

    public java.util.Set<Final_discharge> get_final_discharge() {
        return _final_discharge != null ? _final_discharge : new java.util.HashSet();
    }

    public void set_final_discharge(java.util.Set<Final_discharge> final_discharge) {
        _final_discharge = final_discharge;
    }

    @javax.persistence.OneToMany
    @javax.persistence.JoinColumn(name = "PRISON_FILE_NUMBER")
    private java.util.Set<Shortened_sentence> _shortened_sentence;

    public java.util.Set<Shortened_sentence> get_shortened_sentence() {
        return _shortened_sentence != null ? _shortened_sentence : new java.util.HashSet();
    }

    public void set_shortened_sentence(java.util.Set<Shortened_sentence> shortened_sentence) {
        _shortened_sentence = shortened_sentence;
    }

    public Prisoner() {
        _date_of_birth = new java.util.Date();
    }

    public Prisoner(String prison_file_number) {
        _prison_file_number = prison_file_number;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (_prison_file_number != null ? _prison_file_number.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof Prisoner)) {
            return false;
        } else {
            Prisoner other = (Prisoner) object;
            if (!_prison_file_number.equals(other._prison_file_number)) {
                return false;
            }
        }
        return true;
    }

    @Override
    public String toString() {
        return _prison_file_number + '-' + _given_name + '-' + _surname;
    }
}
