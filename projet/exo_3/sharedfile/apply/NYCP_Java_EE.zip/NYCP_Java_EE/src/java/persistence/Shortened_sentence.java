package persistence;

@javax.persistence.Entity
@javax.persistence.Table(name = "SHORTENED_SENTENCE")
@javax.persistence.DiscriminatorValue("3")
public class Shortened_sentence extends Judicial_decision {

    @Override
    public String get_decision_type_number() {
        return "3";
    }

    @javax.persistence.Column(name = "DURATION")
    private Integer _duration;

    public Integer get_duration() {
        return _duration;
    }

    public void set_duration(Integer duration) {
        _duration = duration;
    }

    public Shortened_sentence() {
        this(null, null);
    }

    public Shortened_sentence(Judicial_decisionPK pk) {
        this(pk.get_prison_file_number(), pk.get_date_of_decision());
    }

    public Shortened_sentence(String prison_file_number, java.util.Date date_of_decision) {
        super("3", prison_file_number, date_of_decision);
    }

    @Override
    public String toString() {
        return "Shortened sentence";
    }
}
