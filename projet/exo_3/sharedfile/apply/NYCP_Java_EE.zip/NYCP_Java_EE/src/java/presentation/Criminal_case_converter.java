package presentation;

@javax.faces.bean.ManagedBean(name = "criminal_case_converter")
@javax.faces.convert.FacesConverter(value = "criminal_cases")
public class Criminal_case_converter implements javax.faces.convert.Converter {

    @Override
    public Object getAsObject(javax.faces.context.FacesContext fc, javax.faces.component.UIComponent uic, String value) {
        if (!value.equals("-1")) {
            return persistence.Criminal_casePK.To_criminal_casePK(value);
        }
        return null;
    }

    @Override
    public String getAsString(javax.faces.context.FacesContext fc, javax.faces.component.UIComponent uic, Object object) {
        return object.toString();
    }
}
