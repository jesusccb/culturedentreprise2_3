package presentation;

@javax.faces.bean.ManagedBean(name = "criminal_case_management")
// By default: @javax.faces.bean.RequestScoped
public class Criminal_case_management {

    @javax.ejb.EJB
    private service.Manage_criminal_case_interface _manage_criminal_case;

    private persistence.Criminal_case _criminal_case;

    public persistence.Criminal_case get_criminal_case() {
        return _criminal_case;
    }
    private persistence.Prisoner _prisoner;

    public persistence.Prisoner get_prisoner() {
        return _prisoner;
    }

    public Criminal_case_management() {
        _criminal_case = new persistence.Criminal_case();
        _prisoner = new persistence.Prisoner();
    }

    public String create() {
        assert (_manage_criminal_case != null);
        _manage_criminal_case.create(_criminal_case);
        return "/criminal_case/All_criminal_cases";
    }

    public String delete() {
        assert (_manage_criminal_case != null);
        String criminal_case_number = javax.faces.context.FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("criminal_case_number");
        String jurisdiction_name = javax.faces.context.FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("jurisdiction_name");
        assert (criminal_case_number != null && jurisdiction_name != null);
        _criminal_case.set_criminal_case_number(criminal_case_number);
        _criminal_case.set_jurisdiction_name(jurisdiction_name);
        _manage_criminal_case.delete(_criminal_case.get_criminal_casePK());
        return "/criminal_case/All_criminal_cases";
    }

    public boolean deletable(String criminal_case_number, String jurisdiction_name) {
        assert (_manage_criminal_case != null);
        if (criminal_case_number != null && jurisdiction_name != null) {
            for (persistence.Criminal_case criminal_case : _manage_criminal_case.criminal_case_deletable()) {
                if (criminal_case_number.equals(criminal_case.get_criminal_case_number()) && jurisdiction_name.equals(criminal_case.get_jurisdiction_name())) {
                    return true;
                }
            }
        }
        return false;
    }

    public java.util.List<persistence.Criminal_case> get_criminal_case_all() {
        assert (_manage_criminal_case != null);
        return _manage_criminal_case.criminal_case_all();
    }
}
