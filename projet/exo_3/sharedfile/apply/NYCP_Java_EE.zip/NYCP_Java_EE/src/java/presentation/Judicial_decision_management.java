package presentation;

@javax.faces.bean.ManagedBean(name = "judicial_decision_management")
// By default: @javax.faces.bean.RequestScoped
public class Judicial_decision_management {

    @javax.ejb.EJB
    private service.Manage_judicial_decision_interface _manage_judicial_decision;

    private persistence.Judicial_decisionPK _judicial_decisionPK;

    public persistence.Judicial_decisionPK get_judicial_decisionPK() {
        return _judicial_decisionPK;
    }

    public void set_judicial_decisionPK(persistence.Judicial_decisionPK judicial_decisionPK) {
        _judicial_decisionPK = judicial_decisionPK;
    }
    private Integer _duration;

    public Integer get_duration() {
        return _duration;
    }

    public void set_duration(Integer duration) {
        _duration = duration;
    }
    private java.util.Date _date_of_final_discharge;

    public java.util.Date get_date_of_final_discharge() {
        return _date_of_final_discharge;
    }

    public void set_date_of_final_discharge(java.util.Date date_of_final_discharge) {
        _date_of_final_discharge = date_of_final_discharge;
    }
    private persistence.Prisoner _prisoner;

    public persistence.Prisoner get_prisoner() {
        return _prisoner;
    }

    public Judicial_decision_management() {
        _prisoner = new persistence.Prisoner();
        _judicial_decisionPK = new persistence.Judicial_decisionPK();
        _duration = 0;
        _date_of_final_discharge = new java.util.Date();
    }

    public String delete() throws java.text.ParseException {
        assert (_manage_judicial_decision != null);
        String decision_type_number = javax.faces.context.FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("decision_type_number");
        String prison_file_number = javax.faces.context.FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("prison_file_number");
        String date_of_decision = javax.faces.context.FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("date_of_decision");
        assert (decision_type_number != null && prison_file_number != null && date_of_decision != null);
        _judicial_decisionPK.set_decision_type_number(decision_type_number);
        _judicial_decisionPK.set_prison_file_number(prison_file_number);
        _judicial_decisionPK.set_date_of_decision(new java.text.SimpleDateFormat("EEE MMM d HH:mm:ss z yyyy", java.util.Locale.US).parse(date_of_decision));
        _manage_judicial_decision.delete(_judicial_decisionPK);
        return "/criminal_case/All_judicial_decisions";
    }

    public boolean deletable(String decision_type_number, String prison_file_number, java.util.Date date_of_decision) {
        assert (_manage_judicial_decision != null);
        if (decision_type_number != null && prison_file_number != null && date_of_decision != null) {
            for (persistence.Judicial_decision judicial_decision : _manage_judicial_decision.judicial_decision_all()) {
                if (decision_type_number.equals(judicial_decision.get_decision_type_number()) && prison_file_number.equals(judicial_decision.get_prison_file_number()) && date_of_decision.equals(judicial_decision.get_date_of_decision())) {
                    return true;
                }
            }
        }
        return false;
    }

    public java.util.List<persistence.Judicial_decision> get_judicial_decision_all() {
        assert (_manage_judicial_decision != null);
        return _manage_judicial_decision.judicial_decision_all();
    }

    public String take_conviction_decision() {
        assert (_manage_judicial_decision != null);
        _manage_judicial_decision.take_conviction_decision(_prisoner, _judicial_decisionPK.get_date_of_decision(), _duration);
        return "/judicial_decision/All_judicial_decisions";
    }

    public String take_final_discharge_decision() {
        assert (_manage_judicial_decision != null);
        _manage_judicial_decision.take_final_discharge_decision(_prisoner, _judicial_decisionPK.get_date_of_decision(), _date_of_final_discharge);
        return "/judicial_decision/All_judicial_decisions";
    }

    public String take_shortened_sentence_decision() {
        assert (_manage_judicial_decision != null);
        _manage_judicial_decision.take_shortened_sentence_decision(_prisoner, _judicial_decisionPK.get_date_of_decision(), _duration);
        return "/judicial_decision/All_judicial_decisions";
    }
}
