package presentation;

@javax.faces.bean.ManagedBean(name = "motive_management")
// By default: @javax.faces.bean.RequestScoped
public class Motive_management {

    @javax.ejb.EJB
    private service.Manage_motive_interface _manage_motive;

    private persistence.Motive _motive;

    public persistence.Motive get_motive() {
        return _motive;
    }

    public Motive_management() {
        _motive = new persistence.Motive();
    }

    public String create() {
        assert (_manage_motive != null && _motive != null);
        _manage_motive.create(_motive);
        return "/motive/All_motives";
    }

    public String delete() {
        assert (_manage_motive != null);
        String motive_number = javax.faces.context.FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("motive_number");
        assert (motive_number != null);
        _motive.set_motive_number(motive_number);
        _manage_motive.delete(_motive);
        return "/motive/All_motives";
    }

    public boolean deletable(String motive_number) {
        assert (_manage_motive != null && motive_number != null);
        for (persistence.Motive motive : _manage_motive.motive_deletable()) {
            if (motive_number.equals(motive.get_motive_number())) {
                return true;
            }
        }
        return false;
    }

    public java.util.List<persistence.Motive> get_motive_all() {
        assert (_manage_motive != null);
        return _manage_motive.motive_all();
    }
}
