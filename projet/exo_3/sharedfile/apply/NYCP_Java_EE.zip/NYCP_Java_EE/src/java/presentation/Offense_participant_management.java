package presentation;

@javax.faces.bean.ManagedBean(name = "offense_participant_management")
@javax.faces.bean.SessionScoped
public class Offense_participant_management {

    @javax.ejb.EJB
    private service.Manage_criminal_case_interface _manage_criminal_case;
    @javax.ejb.EJB
    private service.Manage_prisoner_interface _manage_prisoner;

    private persistence.Criminal_case _criminal_case;

    public persistence.Criminal_case get_criminal_case() {
        return _criminal_case;
    }
    private persistence.Prisoner _prisoner;

    public persistence.Prisoner get_prisoner() {
        return _prisoner;
    }

    public Offense_participant_management() {
        _criminal_case = new persistence.Criminal_case();
        _prisoner = new persistence.Prisoner();
    }

    public String set_offense() {
        String criminal_case_number = javax.faces.context.FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("criminal_case_number");
        String jurisdiction_name = javax.faces.context.FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("jurisdiction_name");
        assert (criminal_case_number != null && jurisdiction_name != null);
        _criminal_case.set_criminal_case_number(criminal_case_number);
        _criminal_case.set_jurisdiction_name(jurisdiction_name);
        return "/criminal_case/Add_participant";
    }

    public String create() {
        assert (_manage_criminal_case != null && _criminal_case != null && _prisoner != null);
        _manage_criminal_case.add_offense_participant(_criminal_case, _prisoner);
        return "/criminal_case/Participants";
    }

    public String delete() {
        assert (_manage_criminal_case != null && _criminal_case != null);
        String prison_file_number = javax.faces.context.FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("prison_file_number");
        assert (prison_file_number != null);
        _prisoner.set_prison_file_number(prison_file_number);
        _manage_criminal_case.remove_offense_participant(_criminal_case, _prisoner);
        return "/criminal_case/Participants";
    }

    public boolean deletable(String prison_file_number) {
        assert (_manage_criminal_case != null && _criminal_case != null && prison_file_number != null);
        _prisoner.set_prison_file_number(prison_file_number);
        return _manage_criminal_case.removable_offense_participant(_criminal_case, _prisoner);
    }

    public java.util.Collection<persistence.Prisoner> get_participants() {
        assert (_manage_prisoner != null);
        return _manage_prisoner.participants(_criminal_case);
    }

    public java.util.Collection<persistence.Prisoner> get_non_participants() {
        assert (_manage_prisoner != null);
        return _manage_prisoner.non_participants(_criminal_case);
    }
}
