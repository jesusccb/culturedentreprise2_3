package presentation;

@javax.faces.bean.ManagedBean(name = "prisoner_management")
// By default: @javax.faces.bean.RequestScoped
public class Prisoner_management {

    @javax.ejb.EJB
    private service.Manage_prisoner_interface _manage_prisoner;

    private persistence.Prisoner _prisoner;

    public persistence.Prisoner get_prisoner() {
        return _prisoner;
    }

    private java.util.Date _date_of_incarceration;

    public java.util.Date get_date_of_incarceration() {
        return _date_of_incarceration;
    }

    public void set_date_of_incarceration(java.util.Date date_of_incarceration) {
        _date_of_incarceration = date_of_incarceration;
    }
    private persistence.Criminal_case _criminal_case;

    public persistence.Criminal_case get_criminal_case() {
        return _criminal_case;
    }

    private persistence.Motive _motive;

    public persistence.Motive get_motive() {
        return _motive;
    }

    public Prisoner_management() {
        _prisoner = new persistence.Prisoner();
        _date_of_incarceration = new java.util.Date();
        _criminal_case = new persistence.Criminal_case();
        _motive = new persistence.Motive();
    }

    public String incarcerate() {
        assert (_manage_prisoner != null && _prisoner != null && _criminal_case != null && _motive != null);
        _prisoner.set_date_of_incarceration(_date_of_incarceration);
        _prisoner.set_incarceration_main(_criminal_case);
        _prisoner.set_incarceration_motive(_motive);
        _manage_prisoner.incarcerate(_prisoner);
        return "/prisoner/All_prisoners";
    }

    public String delete() {
        assert (_manage_prisoner != null);
        String prison_file_number = javax.faces.context.FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("prison_file_number");
        assert (prison_file_number != null);
        _prisoner.set_prison_file_number(prison_file_number);
        _manage_prisoner.delete(_prisoner);
        return "/prisoner/All_prisoners";
    }

    public java.util.List<persistence.Prisoner> get_prisoner_all() {
        assert (_manage_prisoner != null);
        return _manage_prisoner.prisoner_all();
    }

    public java.util.List<persistence.Prisoner> get_prisoner_under_remand() {
        assert (_manage_prisoner != null);
        return _manage_prisoner.prisoner_under_remand();
    }
}
