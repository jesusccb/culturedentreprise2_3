package service;

@javax.ejb.Stateless
public class Manage_criminal_case implements Manage_criminal_case_interface {

    @javax.persistence.PersistenceContext(unitName = "NYCP_persistence_unit")
    private javax.persistence.EntityManager _entityManager;

    @Override
    public persistence.Criminal_case create(persistence.Criminal_case criminal_case) {
        assert (_entityManager != null);
        _entityManager.persist(criminal_case);
        return criminal_case;
    }

    @Override
    public boolean delete(persistence.Criminal_casePK criminal_casePK) {
        assert (_entityManager != null);
        persistence.Criminal_case criminal_case = _entityManager.find(persistence.Criminal_case.class, criminal_casePK);
        if (criminal_case != null) {
            _entityManager.remove(criminal_case);
            return true;
        }
        return false;
    }

    @Override
    public java.util.List<persistence.Criminal_case> criminal_case_all() {
        assert (_entityManager != null);
        return _entityManager.createNamedQuery("Criminal_case.All").getResultList();
    }

    @Override
    public java.util.List<persistence.Criminal_case> criminal_case_deletable() {
        assert (_entityManager != null);
        return _entityManager.createNamedQuery("Criminal_case.Deletable").getResultList();
    }

    @Override
    public boolean add_offense_participant(persistence.Criminal_case criminal_case, persistence.Prisoner prisoner) {
        assert (_entityManager != null);
        boolean result = false;
        criminal_case = _entityManager.find(persistence.Criminal_case.class, new persistence.Criminal_casePK(criminal_case.get_criminal_case_number(), criminal_case.get_jurisdiction_name()));
        prisoner = _entityManager.find(persistence.Prisoner.class, prisoner.get_prison_file_number());
        if (criminal_case != null && prisoner != null) {
            // Non owner side, i.e., '_participant' in 'Criminal_case.java'. No effect in the database:
            result = criminal_case.get_participant().add(prisoner);
            // The consistency between the two association ends must be maintained:
            result &= prisoner.get_offense().add(criminal_case);
            // Owner side, i.e., '_offense' in 'Prisoner.java'
            _entityManager.merge(prisoner);
        }
        return result;
    }

    @Override
    public boolean removable_offense_participant(persistence.Criminal_case criminal_case, persistence.Prisoner prisoner) {
        assert (_entityManager != null);
        boolean result = false;
        criminal_case = _entityManager.find(persistence.Criminal_case.class, new persistence.Criminal_casePK(criminal_case.get_criminal_case_number(), criminal_case.get_jurisdiction_name()));
        prisoner = _entityManager.find(persistence.Prisoner.class, prisoner.get_prison_file_number());
        if (criminal_case != null && prisoner != null) {
            result = !prisoner.get_incarceration_main().equals(criminal_case);
        }
        return result;
    }

    @Override
    public boolean remove_offense_participant(persistence.Criminal_case criminal_case, persistence.Prisoner prisoner) {
        assert (_entityManager != null);
        boolean result = false;
        criminal_case = _entityManager.find(persistence.Criminal_case.class, new persistence.Criminal_casePK(criminal_case.get_criminal_case_number(), criminal_case.get_jurisdiction_name()));
        prisoner = _entityManager.find(persistence.Prisoner.class, prisoner.get_prison_file_number());
        if (criminal_case != null && prisoner != null) {
            result = criminal_case.get_participant().remove(prisoner);
            _entityManager.merge(criminal_case);
        }
        return result;
    }
}
