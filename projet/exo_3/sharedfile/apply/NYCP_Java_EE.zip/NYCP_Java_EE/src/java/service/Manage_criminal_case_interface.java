package service;

@javax.ejb.Local
public interface Manage_criminal_case_interface {

    persistence.Criminal_case create(persistence.Criminal_case criminal_case);

    boolean delete(persistence.Criminal_casePK criminal_casePK);

    java.util.List<persistence.Criminal_case> criminal_case_all();

    java.util.List<persistence.Criminal_case> criminal_case_deletable();

    boolean add_offense_participant(persistence.Criminal_case criminal_case, persistence.Prisoner prisoner);
    
    boolean removable_offense_participant(persistence.Criminal_case criminal_case, persistence.Prisoner prisoner);

    boolean remove_offense_participant(persistence.Criminal_case criminal_case, persistence.Prisoner prisoner);
}
