package service;

@javax.ejb.Stateless
public class Manage_judicial_decision implements Manage_judicial_decision_interface {

    @javax.persistence.PersistenceContext(unitName = "NYCP_persistence_unit")
    private javax.persistence.EntityManager _entityManager;

    @Override
    public persistence.Conviction take_conviction_decision(persistence.Prisoner prisoner, java.util.Date date_of_decision, Integer duration) {
        assert (_entityManager != null);
        persistence.Conviction conviction = new persistence.Conviction(prisoner.get_prison_file_number(), date_of_decision);
        conviction.set_duration(duration);
        _entityManager.persist(conviction);
        return conviction;
    }

    @Override
    public persistence.Final_discharge take_final_discharge_decision(persistence.Prisoner prisoner, java.util.Date date_of_decision, java.util.Date date_of_final_discharge) {
        assert (_entityManager != null);
        persistence.Final_discharge final_discharge = new persistence.Final_discharge(prisoner.get_prison_file_number(), date_of_decision);
        final_discharge.set_date_of_final_discharge(date_of_final_discharge);
        _entityManager.persist(final_discharge);
        return final_discharge;
    }

    @Override
    public persistence.Shortened_sentence take_shortened_sentence_decision(persistence.Prisoner prisoner, java.util.Date date_of_decision, Integer duration) {
        assert (_entityManager != null);
        persistence.Shortened_sentence shortened_sentence = new persistence.Shortened_sentence(prisoner.get_prison_file_number(), date_of_decision);;
        shortened_sentence.set_duration(duration);
        _entityManager.persist(shortened_sentence);
        return shortened_sentence;
    }

    @Override
    public boolean delete(persistence.Judicial_decisionPK judicial_decisionPK) {
        assert (_entityManager != null);
        persistence.Judicial_decision judicial_decision = _entityManager.find(persistence.Judicial_decision.class, judicial_decisionPK);
        if (judicial_decision != null) {
            _entityManager.remove(judicial_decision);
            return true;
        }
        return false;
    }

    @Override
    public java.util.List<persistence.Judicial_decision> judicial_decision_all() {
        assert (_entityManager != null);
        return _entityManager.createNamedQuery("Judicial_decision.All").getResultList();
    }
}
