package service;

@javax.ejb.Local
public interface Manage_judicial_decision_interface {

    persistence.Conviction take_conviction_decision(persistence.Prisoner prisoner, java.util.Date date_of_decision, Integer duration);

    persistence.Final_discharge take_final_discharge_decision(persistence.Prisoner prisoner, java.util.Date date_of_decision, java.util.Date date_of_final_discharge);

    persistence.Shortened_sentence take_shortened_sentence_decision(persistence.Prisoner prisoner, java.util.Date date_of_decision, Integer duration);

    boolean delete(persistence.Judicial_decisionPK judicial_decisionPK);

    java.util.List<persistence.Judicial_decision> judicial_decision_all();
}
