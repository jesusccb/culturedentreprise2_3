package service;

@javax.ejb.Stateless
public class Manage_motive implements Manage_motive_interface {

    @javax.persistence.PersistenceContext(unitName = "NYCP_persistence_unit")
    private javax.persistence.EntityManager _entityManager;

    @Override
    public persistence.Motive create(persistence.Motive motive) {
        assert (_entityManager != null);
        _entityManager.persist(motive);
        return motive;
    }

    @Override
    public boolean delete(persistence.Motive motive) {
        assert (_entityManager != null);
        motive = _entityManager.find(persistence.Motive.class, motive.get_motive_number());
        if (motive != null) {
            _entityManager.remove(motive);
            return true;
        }
        return false;
    }

    @Override
    public java.util.List<persistence.Motive> motive_all() {
        assert (_entityManager != null);
        return _entityManager.createNamedQuery("Motive.All").getResultList();
    }

    @Override
    public java.util.List<persistence.Motive> motive_deletable() {
        assert (_entityManager != null);
        return _entityManager.createNamedQuery("Motive.Deletable").getResultList();
    }
}
