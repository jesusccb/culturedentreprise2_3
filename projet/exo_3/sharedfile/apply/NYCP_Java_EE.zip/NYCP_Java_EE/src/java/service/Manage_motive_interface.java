package service;

@javax.ejb.Local
public interface Manage_motive_interface {

    persistence.Motive create(persistence.Motive motive);

    boolean delete(persistence.Motive motive);

    java.util.List<persistence.Motive> motive_all();

    java.util.List<persistence.Motive> motive_deletable();
}
