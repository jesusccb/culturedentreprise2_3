package service;

@javax.ejb.Stateless
public class Manage_prisoner implements Manage_prisoner_interface {

    @javax.persistence.PersistenceContext(unitName = "NYCP_persistence_unit")
    private javax.persistence.EntityManager _entityManager;

    @Override
    public persistence.Prisoner incarcerate(persistence.Prisoner prisoner) {
        assert (_entityManager != null);
        _entityManager.persist(prisoner);
        return prisoner;
    }

    @Override
    public boolean delete(persistence.Prisoner prisoner) {
        assert (_entityManager != null);
        prisoner = _entityManager.find(persistence.Prisoner.class, prisoner.get_prison_file_number());
        if (prisoner != null) {
            _entityManager.remove(prisoner);
            return true;
        }
        return false;
    }

    @Override
    public java.util.List<persistence.Prisoner> prisoner_all() {
        assert (_entityManager != null);
        return _entityManager.createNamedQuery("Prisoner.All_JPQL").getResultList();
    }

    @Override
    public java.util.List<persistence.Prisoner> prisoner_under_remand() {
        assert (_entityManager != null);
        return _entityManager.createNamedQuery("Prisoner.Under_remand_JPQL").getResultList();
    }

    @Override
    public java.util.Collection<persistence.Prisoner> participants(persistence.Criminal_case criminal_case) {
        assert (_entityManager != null);
        criminal_case = _entityManager.find(persistence.Criminal_case.class, new persistence.Criminal_casePK(criminal_case.get_criminal_case_number(), criminal_case.get_jurisdiction_name()));
        return criminal_case.get_participant();
    }

    @Override
    public java.util.Collection<persistence.Prisoner> non_participants(persistence.Criminal_case criminal_case) {
        assert (_entityManager != null);
        criminal_case = _entityManager.find(persistence.Criminal_case.class, new persistence.Criminal_casePK(criminal_case.get_criminal_case_number(), criminal_case.get_jurisdiction_name()));
// The following query ("Prisoner.Not_involved_in_criminal_case_V1") relies on the "owned" association end (i.e., '_offense'): "SELECT p FROM Prisoner p WHERE :criminal_case NOT MEMBER OF p._offense"
        return _entityManager.createNamedQuery("Prisoner.Not_involved_in_criminal_case_V1").setParameter("criminal_case", criminal_case).getResultList();
// Note that "Prisoner.Not_involved_in_criminal_case_V2" query requires 'cascade = javax.persistence.CascadeType.MERGE'
    }
}
