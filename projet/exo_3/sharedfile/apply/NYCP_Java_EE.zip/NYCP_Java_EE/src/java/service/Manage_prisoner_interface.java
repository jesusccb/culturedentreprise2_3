package service;

@javax.ejb.Local
public interface Manage_prisoner_interface {

    persistence.Prisoner incarcerate(persistence.Prisoner prisoner);

    boolean delete(persistence.Prisoner prisoner);

    java.util.List<persistence.Prisoner> prisoner_all();

    java.util.List<persistence.Prisoner> prisoner_under_remand();

    java.util.Collection<persistence.Prisoner> participants(persistence.Criminal_case criminal_case);

    java.util.Collection<persistence.Prisoner> non_participants(persistence.Criminal_case criminal_case);
}
